/*
Autores:
Germano
Leonardo
*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

typedef struct {
    int linha;
    int colunas;
    int **A, **B, **C;
} ThreadDados;

void* soma_linhas(void* arg) {
    ThreadDados* dado = (ThreadDados*)arg;
    for (int i = 0; i < dado->colunas; i++) {
        dado->C[dado->linha][i] = dado->A[dado->linha][i] + dado->B[dado->linha][i];
    }
    return NULL;
}

int main() {
    int N, M;
    int **A;
    int **B;
    int **C;
    
    printf("Dimensoes da matriz NxM:\n");
    scanf("%d %d", &N, &M);
    printf("\n");

    // Alocacao dinamica
	A = malloc(N * sizeof(int*));
    B = malloc(N * sizeof(int*));
    C = malloc(N * sizeof(int*));
    for (int i = 0; i < N; i++) {
        A[i] = malloc(M * sizeof(int));
        B[i] = malloc(M * sizeof(int));
        C[i] = malloc(M * sizeof(int));
        for (int j = 0; j < M; j++) {
            A[i][j] = rand() % 10;
            B[i][j] = rand() % 10;
        }
    }
    
    printf("Matriz A gerada:\n");
    for (int i=0;i <N;i++){
    	
    	for (int j=0;j<M;j++){
    		
    		printf("%i ",A[i][j]);
    		
		}
    	
    	printf("\n");
    	
	}
	printf("\n");
	
	printf("Matriz B gerada:\n");
    for (int i=0;i <N;i++){
    	
    	for (int j=0;j<M;j++){
    		
    		printf("%i ",B[i][j]);
    		
		}
    	
    	printf("\n");
    	
	}
	printf("\n");

    pthread_t threads[N];
    ThreadDados dados[N];

    for (int i = 0; i < N; i++) {
        dados[i].linha = i;
        dados[i].colunas = M;
        dados[i].A = A; dados[i].B = B; dados[i].C = C;
        pthread_create(&threads[i], NULL,soma_linhas,&dados[i]);
    }

    for (int i = 0; i < N; i++) pthread_join(threads[i], NULL);

    printf("Matriz resultante da soma:\n");
    for (int i=0;i <N;i++){
    	
    	for (int j=0;j<M;j++){
    		
    		printf("%i ",C[i][j]);
    		
		}
    	
    	printf("\n");
    	
	}
	
	for (int i = 0; i < N; i++) {
        free(A[i]); 
        free(B[i]); 
        free(C[i]); 
    }
	free(A);
	free(B);
	free(C);
    
    return 0;
}
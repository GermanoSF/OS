/*
Autores:
Germano
Leonardo
*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

// Estrutura para passar dados para cada thread
typedef struct {
    int linha;          // A linha especifica que esta thread vai processar
    int n;              // Dimensao N
    int **matriz;     // Ponteiro para a matriz NxN
    int *vetor;       // Ponteiro para o vetor de entrada
    int *resultado;   // Ponteiro para o vetor de saida
} DadosMult;

void* tarefa_multiplicacao(void* arg) {
    DadosMult* d = (DadosMult*)arg;
    
    d->resultado[d->linha] = 0;
    for (int j = 0; j < d->n; j++) {
        d->resultado[d->linha] += d->matriz[d->linha][j] * d->vetor[j];
    }
    
    return NULL;
}

int main() {
    int N;
    printf("Digite a ordem N da matriz quadrada: ");
    if (scanf("%i", &N) != 1) return 1;

    int **matriz = (int**)malloc(N * sizeof(int*));
    int *vetor = (int*)malloc(N * sizeof(int));
    int *resultado = (int*)malloc(N * sizeof(int));

    for (int i = 0; i < N; i++) {
        matriz[i] = (int*)malloc(N * sizeof(int));
        vetor[i] = (int)(rand() % 5);
        for (int j = 0; j < N; j++) {
            matriz[i][j] = rand() % 5;
        }
    }
    
    printf("matriz gerada:\n");
    for (int i=0;i<N;i++){
    	
    	for (int j=0;j<N;j++){
    		
    		printf("%i ",matriz[i][j]);
    		
		}
		
		printf("\n");
    	
	}
	printf("\n");
	
	printf("vetor gerado:\n");
	for (int i=0;i<N;i++){
		
		printf("%i ",vetor[i]);
		
	}
	printf("\n");

    pthread_t threads[N];
    DadosMult info_threads[N];

    // Criacao das threads
    for (int i = 0; i < N; i++) {
        info_threads[i].linha = i;
        info_threads[i].n = N;
        info_threads[i].matriz = matriz;
        info_threads[i].vetor = vetor;
        info_threads[i].resultado = resultado;
        
        pthread_create(&threads[i], NULL, tarefa_multiplicacao, &info_threads[i]);
    }

    // Aguarda todas as threads terminarem
    for (int i = 0; i < N; i++) {
        pthread_join(threads[i], NULL);
    }

    // Exibicao do resultado
    printf("\nMultiplicacao concluida.\nVetor Resultado:\n");
    for (int i = 0; i < N; i++) {
        printf("%i ", resultado[i]);
    }
    printf("\n");

    for (int i = 0; i < N; i++) {
        free(matriz[i]);
    }
    free(matriz);
    free(vetor);
    free(resultado);

    return 0;
}
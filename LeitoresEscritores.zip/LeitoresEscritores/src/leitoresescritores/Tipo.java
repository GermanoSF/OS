/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package leitoresescritores;

/**
 *
 * @author gspal
 */
public class Tipo {
    
    private String variavelCompartilhada;
    private String escreveuJa;
    
    public Tipo(String variavelCompartilhada,String escreveuJa){
        
        this.variavelCompartilhada = variavelCompartilhada;
        this.escreveuJa = escreveuJa;
        
    }
    
    public synchronized void leitor(int id) throws InterruptedException{
        
        if (this.escreveuJa == null){
            wait();
        }
        this.escreveuJa = null;
        System.out.println("Leitor "+id+"-> leu: "+this.variavelCompartilhada);
        notifyAll();
        
    }
    
    public synchronized void escritor(String conteudo) throws InterruptedException{
        
       while (escreveuJa != null){ 
            wait();
        }
        
        this.escreveuJa = "S";
        System.out.println("Escrevendo: "+conteudo);
        this.variavelCompartilhada = conteudo;
        notifyAll();
        
    }
    
}

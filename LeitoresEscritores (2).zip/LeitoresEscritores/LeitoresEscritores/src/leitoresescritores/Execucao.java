/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package leitoresescritores;

/**
 *
 * @author gspal
 */
public class Execucao implements Runnable{
    
    private Acao tipo;
    private String lerEscrever;
    private int id;
    private String conteudo;
    
    public Execucao(Acao tipo, String lerEscrever, int id, String conteudo){
        
        this.tipo = tipo;
        this.lerEscrever = lerEscrever;
        this.id = id;
        this.conteudo = conteudo;
        
    }
    
    public void run(){
        
        if (this.lerEscrever.equals("ler")){
            while(true){
                try{
                    Thread.sleep(300);
                    this.tipo.ler(this.id);
                }catch(Exception e) {}
            }
          
        }
        else{
            try{
                this.tipo.escrever(new String(this.conteudo));
            }catch(Exception e) {}
            
        }
        
    }
    
}

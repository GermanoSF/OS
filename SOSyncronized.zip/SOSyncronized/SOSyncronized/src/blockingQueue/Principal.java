/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blockingQueue;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author laboratorio
 */
public class Principal {
    
    public static void main(String[] args) {
        
        int tamanhoFila = 20;

        Fila fila = new Fila(tamanhoFila);
        
        List<Thread> jogadores = new ArrayList<>();
        
        Nicknames nicknames = new Nicknames("C:/Users/gspal/Downloads/nicks.txt");
        
        for (int i=0;i<40;i++) jogadores.add(new Thread(new Jogador(Integer.parseInt(nicknames.pegar(1,i)),new String(nicknames.pegar(0,i)),fila)));
        
        Thread servidor = new Thread(new Servidor(fila));
        
        servidor.start();
        
        for (Thread jogador : jogadores){
            
            jogador.start();
            
        }
        
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blockingQueue;

/**
 *
 * @author laboratorio
 */
public class Servidor implements Runnable{
    
    private Fila fila;
    
    public Servidor(Fila fila){
        
        this.fila = fila;
        
    }
    
    @Override
    public void run(){
        
        try{
            
            while (true){
                
                fila.coletar();
                Thread.sleep(300);
                
            }
            
        } catch(InterruptedException e){
            
            Thread.currentThread().interrupt();
            
        }
        
    }
    
}

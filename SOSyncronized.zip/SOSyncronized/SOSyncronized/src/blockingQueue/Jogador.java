/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blockingQueue;

/**
 *
 * @author laboratorio
 */
public class Jogador implements Runnable{
    
    private int id;
    
    private String nickname;
    
    private Fila fila;
    
    public Jogador (int id, String nickname, Fila fila){
        
        this.id = id;
        this.nickname = nickname;
        this.fila = fila;
        
    }
    
    public Jogador (int id, String nickname){
        
        this.id = id;
        this.nickname = nickname;
        
    }
    
    @Override
    public void run(){
        
        try{
            
            fila.inserir(new Jogador(this.id,new String(this.nickname)));
            
        }catch(InterruptedException e){
            
            Thread.currentThread().interrupt();
            
        }
        
    }

    public int getId() {
        return id;
    }

    public String getNickname() {
        return nickname;
    }
    
    @Override
    public String toString(){
        
        return ("nickname: "+this.nickname+" - ID: "+this.id);
        
    }
    
}

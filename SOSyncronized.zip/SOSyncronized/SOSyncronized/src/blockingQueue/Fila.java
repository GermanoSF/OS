/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blockingQueue;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

/**
 *
 * @author laboratorio
 */
public class Fila {
    
    private BlockingQueue<Jogador> fila;
    
    public Fila(int tamanho){
        
        this.fila = new ArrayBlockingQueue<>(tamanho);
        
    }
    
    public void inserir(Jogador jogador) throws InterruptedException {
        
        while(!fila.offer(jogador)){}
        
        System.out.println("Jogador inserido -> "+jogador);
        
    }
    
    public void coletar() throws InterruptedException {
        
        try{
            
            System.out.println("Jogadores pareados: "+fila.take()+" |vs| "+fila.take());
            
        }catch(InterruptedException e){}
        
    }
    
}

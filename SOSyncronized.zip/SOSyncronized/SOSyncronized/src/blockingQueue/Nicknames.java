/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blockingQueue;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author gspal
 */
public class Nicknames {
    
    private List<String[]> dados = new ArrayList<>(); 
    
    public Nicknames(String caminhoO){
        
        Path caminho = Paths.get(caminhoO);

        try (BufferedReader br = Files.newBufferedReader(caminho)) {
            
            List<String> dadosTemp = new ArrayList<>();
            String linha;
            
            while ((linha = br.readLine()) != null) {
                
                dadosTemp.add(new String(linha));
                
            }  
            
            for (String dado: dadosTemp) this.dados.add(dado.split(","));
          
            
        } catch (IOException e) {
            System.err.println("Erro ao ler o arquivo: " + e.getMessage());
        }
        
    }
    
    public String pegar(int nickId, int jogador){
    
        if (dados.isEmpty()) return "erro";
        
        return dados.get(jogador)[nickId];
    
    }
    
}

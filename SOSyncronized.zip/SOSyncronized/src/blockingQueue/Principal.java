/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blockingQueue;

/**
 *
 * @author laboratorio
 */
public class Principal {
    
    public static void main(String[] args) {
        
        Fila buffer = new Fila();
        
        Thread produtor = new Thread(new Jogador(buffer));
        
        Thread consumidor = new Thread(new Servidor(buffer));
        
        produtor.start();
        consumidor.start();
        
    }
    
}

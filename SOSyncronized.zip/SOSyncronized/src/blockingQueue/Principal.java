/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blockingQueue;

/**
 *
 * @author laboratorio
 */
public class Principal {
    
    public static void main(String[] args) {
        
        int tamanhoFila = 20;
                
        boolean[] pode = new boolean[tamanhoFila];

        Fila buffer = new Fila(tamanhoFila);
        
        for (int i=0;i<20;i++) pode[i] = true;
        
        
        Thread Jogador = new Thread(new Jogador(buffer));
        
        Thread consumidor = new Thread(new Servidor(buffer));
        
        produtor.start();
        consumidor.start();
        
    }
    
}

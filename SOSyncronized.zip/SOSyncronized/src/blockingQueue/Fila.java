/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blockingQueue;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

/**
 *
 * @author laboratorio
 */
public class Fila {
    
    private Jogador jogador1;
    private Jogador jogador2;
    
    private BlockingQueue<Jogador> fila = new ArrayBlockingQueue<>(20);
    
    public void inserir(Jogador jogador,boolean[] pode) throws InterruptedException {
        
        fila.put(jogador);
        
        System.out.println("Jogador inserido: "+jogador.getNickname()+" "+jogador.getId());
        
        if (pode[0] == false){
            
            pode[0] = true;
            
        } else{
            
            pode[1] = true;
            
        }
        
    }
    
    public void coletar(boolean[] pode) throws InterruptedException {
        
        jogador1 = fila.take();
        jogador2 = fila.take();
        
        while(pode[0] == false || pode[1] == false);
        
        System.out.println("Jogadores pareados: "+jogador1.getNickname()+" "+jogador1.getId()+
                           " - "+ jogador2.getNickname()+" "+jogador2.getId());
        
        pode[0] = false;
        pode[1] = false;
        
    }
    
}
